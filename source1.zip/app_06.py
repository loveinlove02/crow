from openai import OpenAI
from dotenv import load_dotenv
import os
import base64

import cv2

import time

load_dotenv(verbose=True)
key = os.getenv('OPENAI_API_KEY')

img_file = 'a.jpg'
base64_image = None

client = OpenAI(api_key=key)

def encode_image(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')
    
def request():
    response = client.chat.completions.create(
        model="gpt-4o", 
        messages=[
            {
                'role':'system', 'content':'당신은 이미지 분석 전문가입니다. 0~100사이의 숫자로 답변하세요. 쓸데 없는 말은 하지말아주세요. 한국어로 답변해주세요.'
            },
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "이미지에서 혼잡도를 알려주세요."},
                    {"type": "image_url", "image_url": {"url":  f"data:image/jpeg;base64,{base64_image}"}},
                ],
            }
        ],
        max_tokens=256,        
    )

    text = response.choices[0].message.content

    return text


cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()

    if not ret:
        print('프레임 없다')
        break
    
    if cv2.waitKey(1) != -1:    # 1ms 동안 대기
        break                   # 아무키나 눌렀으면 중지
    
    cv2.imshow('camera', frame)

    cv2.imwrite(img_file, frame)
    base64_image = encode_image(img_file)

    answer = request()
    
    print(answer)
    print(type(answer))

    
    time.sleep(2)

cap.release()
cv2.destroyAllWindows()



    




    
