import firebase_admin
from firebase_admin import credentials
from firebase_admin import db, storage

cred=credentials.Certificate('firebase.json')
firebase_admin.initialize_app(cred,{
    'databaseURL' : 'https://cho2-9857c.firebaseio.com/'
})

ref = db.reference('case/case1')
print(ref.get())
# ref2 = db.reference('case')
# ref2.update({'case1':'blue'}) 