from openai import OpenAI
from dotenv import load_dotenv
import os
import base64

load_dotenv(verbose=True)
key = os.getenv('OPENAI_API_KEY')

img_file = 'a5.jpg'
base64_image = None

client = OpenAI(api_key=key)

def encode_image(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')
    
def request():
    response = client.chat.completions.create(
        model="gpt-4o", 
        messages=[
            {
                'role':'system', 'content':'당신은 이미지 분석 전문가입니다. 0~100사이의 숫자로 답변하세요. 쓸데 없는 말은 하지말아주세요. 한국어로 답변해주세요.'
            },
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "지하철의 혼잡도를 알려주세요."},
                    {"type": "image_url", "image_url": {"url":  f"data:image/jpeg;base64,{base64_image}"}},
                ],
            }
        ],
        max_tokens=500,        
    )

    # print(response.choices[0])
    text = response.choices[0].message.content

    return text

base64_image = encode_image(img_file)

answer = request()
print(answer)
print(type(answer))
